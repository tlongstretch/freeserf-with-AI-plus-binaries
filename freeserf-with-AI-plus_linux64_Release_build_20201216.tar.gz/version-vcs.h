#ifndef VERSION_VCS_H
#define VERSION_VCS_H

#define VERSION_VCS "0.3.b978fcf"

#endif /* VERSION_VCS_H */
